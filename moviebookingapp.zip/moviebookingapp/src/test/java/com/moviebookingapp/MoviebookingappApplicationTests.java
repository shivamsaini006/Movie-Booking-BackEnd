package com.moviebookingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviebookingappApplicationTests {

	@Test
	public void main() {
	MoviebookingappApplication.main(new String[] {}); 

	}

}
