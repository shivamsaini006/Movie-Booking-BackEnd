package com.moviebookingapp.exception;

public class MovieNotAvailableException extends Exception{
	
	public MovieNotAvailableException(String msg) {
		super(msg);
	}

}
